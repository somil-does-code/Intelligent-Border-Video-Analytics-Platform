# IBVAP — Intelligent Border Video Analytics Platform

Hackathon-ready combined website using the supplied frontend and backend prototype.

## What is included
- Flask web server serving the dashboard
- Original human/vehicle detection, ANPR and suspicious-activity modules
- Live dashboard API (`/api/dashboard`)
- Camera API (`/api/cameras`)
- Browser CCTV stream (`/video_feed`)
- Demo mode that works without a camera/model
- AI mode that uses the supplied OpenCV/YOLO backend when a video source is available
- Interactive sectors A-3, B-1 and C-4
- Threat log, metrics and prototype alert generation

## Run the website

### 1. Create a virtual environment
Windows:
```bat
py -3 -m venv .venv
.venv\Scripts\activate
```

### 2. Install dependencies
```bat
pip install -r requirements.txt
```

If you only want to run the UI/demo mode, Flask, OpenCV and NumPy are enough; the AI packages are needed for AI mode.

### 3. Start
```bat
python app.py
```

Open http://127.0.0.1:5000

## Demo flow
1. Open the dashboard.
2. Click A-3, B-1 or C-4 to switch sectors.
3. Click **Generate Alert** to demonstrate the real-time event log.
4. Click **Switch to AI** when you have a webcam/video source available.

## AI video source
The current web UI starts in safe demo mode. For a real video source, the backend's AI stream supports webcam index `0` or a video/RTSP source. The supplied detection modules are kept under `detection/`, ANPR under `anpr/`, and suspicious activity under `suspicious/`.

## Important
This is a hackathon prototype. It is not validated for real border-security operations and should not be represented as production-ready surveillance software.
